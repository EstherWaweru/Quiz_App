package com.example.estherwaweru.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
 private int result=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    //This method uses a switch case to determine which radio button was clicked and updates the score
    public void firstQuestion(View view){
        boolean checked=((RadioButton)view).isChecked();
        switch(view.getId()){
            case R.id.radio_android:
                if (checked)
                    result+=10;
                break;
            case R.id.radio_Xcode:
                if(checked)
                    result+=0;
                break; }
    }
    public void secondQuestion(View view){
            boolean checked=((RadioButton)view).isChecked();
            switch(view.getId()){
                case R.id.radio_linear:
                    if (checked)
                        result+=10;
                    break;
                case R.id.radio_vertical:
                    if(checked)
                        result+=0;
                    break;
                case R.id.radio_horizontal:
                    if(checked)
                        result+=0;
                    break; }
    }

   //This method uses a switch case to determine which box was clicked and updates the score
    public void fourthQuestion(View view){
                boolean checked=((CheckBox)view).isChecked();
                switch(view.getId()){
                    case R.id.vertical_checkbox:
                        if (checked)
                            result+=10;
                        else
                            result-=10;
                        break;
                    case R.id.horizontal_checkbox:
                        if(checked)
                            result+=10;
                        else
                            result-=10;
                        break;
                    case R.id.relative_checkbox:
                        if(checked)
                            result+=0;
                        break; }
    }
    public void fifthQuestion(View view){
        boolean checked=((CheckBox)view).isChecked();
        switch(view.getId()){
            case R.id.textstyle_checkbox:
                if (checked)
                    result+=10;
                else
                    result-=10;
                break;
            case R.id.textvisibility_checkbox:
                if(checked)
                    result+=10;
                else
                    result-=10;
                break;
            case R.id.orientation_checkbox:
                if(checked)
                    result+=0;
                break;}
    }
    /*This method is for checking the answer given in the EditText field and uses a Toast message to
    display final results*/
    public void submitAnswers(View view){
        EditText mEdittext=(EditText) findViewById(R.id.edittext_answer);
        String answer=mEdittext.getText().toString();
        String ans="Xcode";
        if(answer.trim().equalsIgnoreCase(ans)) {
            result+=10;}

        String grade="Thanks for attempting the quiz,Your score is:"+result;

        Toast toast=Toast.makeText(this,grade,Toast.LENGTH_SHORT);
        toast.show(); }

        //The retryTest resets all the input fields so that one can attempt the quiz again.
        public void retryTest(View view){
        result=0;
        RadioButton rad1=(RadioButton) findViewById(R.id.radio_android);
        rad1.setChecked(false);
        RadioButton radi2=(RadioButton) findViewById(R.id.radio_Xcode);
        radi2.setChecked(false);
        RadioButton rad3=(RadioButton) findViewById(R.id.radio_linear);
        rad3.setChecked(false);
        RadioButton rad4=(RadioButton) findViewById(R.id.radio_horizontal);
        rad4.setChecked(false);
        RadioButton rad5=(RadioButton) findViewById(R.id.radio_vertical);
        rad5.setChecked(false);
        CheckBox cbox1=(CheckBox) findViewById(R.id.horizontal_checkbox);
        cbox1.setChecked(false);
        CheckBox cbox2=(CheckBox) findViewById(R.id.vertical_checkbox);
        cbox2.setChecked(false);
        CheckBox cbox3=(CheckBox) findViewById(R.id.orientation_checkbox);
        cbox3.setChecked(false);
        CheckBox cbox4=(CheckBox) findViewById(R.id.relative_checkbox);
        cbox4.setChecked(false);
        CheckBox cbox5=(CheckBox) findViewById(R.id.textstyle_checkbox);
        cbox5.setChecked(false);
        CheckBox cbox6=(CheckBox) findViewById(R.id.textvisibility_checkbox);
        cbox6.setChecked(false);
        EditText text=(EditText) findViewById(R.id.edittext_answer);
        text.setText("");
        }
}
