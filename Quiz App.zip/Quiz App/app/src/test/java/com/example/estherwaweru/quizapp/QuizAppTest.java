package com.example.estherwaweru.quizapp;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.JUnit4;

import static org.junit.Assert.*;

@RunWith(JUnit4.class)
public class QuizAppTest {

    @Test
    public void secondQuestion(){


    }


}
